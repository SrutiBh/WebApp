var React = require("react");
var sw = require("stopword");
var actions = require("../actions/SchoolActions");

module.exports = React.createClass({
    getInitialState:function(){
      return {
          name:"",
          tagline:""
      }  
    },
    addSchool:function(e){
        e.preventDefault();
	var state1 = { name:"", tagline:"" };
	state1.name = sw.removeStopwords(this.state.name.split(" ")).join().replace(/,/g, ' ');
		state1.tagline = sw.removeStopwords(this.state.tagline.split(" ")).join().replace(/,/g, ' ');

        actions.addSchool(state1);
    },
    handleInputChange:function(e){
      e.preventDefault();
      var name = e.target.name;
      var state = this.state;
      state[name] = e.target.value;
      this.setState(state);
    },
    render:function(){
        return(
            <form className="form" onSubmit={this.addSchool}>
                <div className="form-group">
                    <label className="control-label" htmlFor="name">Todo Item:</label>
                    <input type="text" className="form-control" id="name" name="name" value={this.state.name} onChange={this.handleInputChange} placeholder="Todo Item" />                    
                </div>
                <div className="form-group">
                    <label className="control-label" htmlFor="tagline">Description:</label>
                    <input type="text" className="form-control" id="tagline" name="tagline" value={this.state.address} onChange={this.handleInputChange} placeholder="Description" />                    
                </div>
                <div className="form-group">
                    <button className="btn" type="submit">Add Todo</button>
                </div>
            </form>
        )
    }
})